uch(X,Y):-stud(X),prepod(Y),izuch(X,Z),prepodayet(Y,Z).

dvbabushka(X,Y):-woman(Y),grandfather(X,F),sister(F,Y).
dvbabushka(X,Y):-woman(Y),grandmother(X,M),sister(M,Y).


poisk(VP):-zoo(J, VP, NK, V, P),write(J),nl,1=0.
poisk(VP):-zoo(J, V, NK, VES, VP),write(J),nl,false.
