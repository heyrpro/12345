vmenu('pelmeni', 150, 200).
vmenu('pica', 320, 210).
vmenu('sup', 120, 180).
vmenu('olive', 80, 90).
vmenu('chai', 30, 20).
vmenu('kofe', 50, 30).
vmenu('koktel', 60, 40).
vmenu('cezar', 95, 85).
vmenu('lobster', 550, 260).
vmenu('burger', 170, 160).
vmenu('spagetti', 160, 200).
vmenu('ramen', 165, 210).
vmenu('ikra', 200, 100).
vmenu('suhi', 230, 230).
vmenu('kombo', 400, 270).

getcost(X):-vmenu(X,Y,Z),write(X),write(' - '),write(Y),write('rub').
getkkal(X):-vmenu(X,Y,Z),write(X),write(' - '),write(Z),write('kkal').
getall():-vmenu(X,Y,Z),write(X),write(' - '),write(Y),write('rub'),write(' - '),write(Z),write('kkal'),nl,0=1.
getprod(X,Y):-vmenu(P,R,K),R<X,K<Y,write(P),write(' - '),write(R),write(' - '),write(K),nl,0=1.
