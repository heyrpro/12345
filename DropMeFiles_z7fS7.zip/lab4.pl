pr_list([], 1):-!.
pr_list([Head|Tail], Pr):-
    pr_list(Tail, TailPr),
    Pr is TailPr * Head.

pr_lists([], []):-!.
pr_lists([Head|Tail], [HeadNew|TailNew]):-
    pr_list(Head, HeadNew),
    pr_lists(Tail, TailNew).
