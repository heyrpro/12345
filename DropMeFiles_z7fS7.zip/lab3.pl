/*
f(0,S,X):-write('('),write(X),write('-1)^0 = 1'),nl,!.
f(N,S,X):-N1 is N-1,f(N1,S1,X),S is (X-1)**N,write('('),write(X),write('-1)^'),write(N),write(' = '),write(S),nl.
*/

f(N,S,I,J,X):-N=I, S is J,write('('),write(X),write(' - 1)^0 = 1'),nl.
f(N,S,I,J,X):-I1 is I+1, N1 is N-I,J1 is (X-1)**N1, write('('),write(X),write(' - 1)^'),write(N1),write(' = '),write(J1),nl,f(N,S,I1,J1,X).

/*

*/




/*
f(0,S,X):-!.
f(N,S,X):-N1 is N-1,f(N1,S1,X),S is (X-1)**N.
xn(0,X,S):-write('('),write(X),write('-1)^0 = 1'),nl.
xn(N,X,S):-f(N,S1,X),N1 is N-1,xn(N1,X,S2),S is S1,write('('),write(X),write('-1)^'),write(N),write(' = '),write(S),nl.

f(N,S,I,J,X):-N=I, S is J.
f(N,S,I,J,X):-J1 is (X-1)**N, f(N,S,I1,J1,X).
xn(N,X,S,I,J):-N=I, S is J, write('('),write(X),write(' - 1)^0 = 1'),nl.
xn(N,X,S,I,J):-I1 is I+1, N1 is N-I,f(N1,S1,0,0,X),J1 is S1, write('('),write(X),write(' - 1)^'),write(N1),write(' = '),write(J1),nl,xn(N,X,S,I1,J1).
*/
