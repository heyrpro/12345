/*
f(_, 0, Res):-
    !, Res is 1.
f(_, 1, Res):-
    !, Res is 2.
f(X, N, Res):-
    N1 is N - 1, N2 is N - 2,
    f(X, N2, Res2),
    f(X, N1, Res1),
    Res is N * Res2 / Res1 + X * Res2.

flist(X, N, List):-
N =< 0, !, List = [];
f(X, N, HeadValue),
N1 is N - 1, flist(X, N1, Tail),
List = [HeadValue|Tail].
*/

count(Tree, Count):-
    Tree = empty, !, Count is 0;
    Tree = tree(_, empty, empty), !, Count is 0;
    Tree = tree(_, Left, Right),
    count(Left, LeftCount),
    count(Right, RightCount),
    Count is LeftCount + RightCount + 1.

sum(Tree, Sum):-
    Tree = empty, !, Sum is 0;
    Tree = tree(_, empty, empty), !, Sum is 0;
    Tree = tree(Value, Left, Right),
    sum(Left, LeftCount),
    sum(Right, RightCount),
    Sum is LeftCount + RightCount + Value.

avg(Tree, Avg):-
    count(Tree, Count),
    sum(Tree, Sum),
    Count > 0, !, Avg is Sum/Count.

count_sum(Tree, Count, Sum):-
    Tree = empty, !, Count is 0, Sum is 0;
    Tree = tree(_, empty, empty), !, Count is 0, Sum is 0;
    Tree = tree(Value, Left, Right),
    count_sum(Left, LeftCount, LeftSum),
    count_sum(Right, RightCount, RightSum),
    Count is LeftCount + RightCount + 1,
    Sum is LeftSum + RightSum + Value.

avg(Tree, Avg):-
    count_sum(Tree, Count, Sum),
    Count > 0, !, Avg is Sum/Count.
