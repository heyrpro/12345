man('Marat').
man('Vagiz').
man('Tahir').
man('Rafik').
man('Javat').
man('Vadim').
man('Airat').
man('Aidar').
man('Anvar').

woman('Elmira').
woman('Venera').
woman('Elvira').
woman('Guzalya').
woman('Dehira').
woman('Liana').

parent('Marat','Rafik').
parent('Marat','Elmira').

parent('Tahir','Rafik').
parent('Tahir','Elmira').

parent('Vagiz','Rafik').
parent('Vagiz','Elmira').

parent('Rafik','Javat').
parent('Rafik','Venera').

parent('Elvira','Javat').
parent('Elvira','Venera').

parent('Elmira','Dehira').
parent('Guzalya','Dehira').

parent('Vadim','Guzalya').

parent('Airat','Elvira').
parent('Airat','Anvar').

parent('Aidar','Elvira').
parent('Aidar','Anvar').

parent('Liana','Elvira').
parent('Liana','Anvar').


father(X,Y):-man(Y),parent(X,Y),X\=Y.
mother(X,Y):-woman(Y),parent(X,Y),X\=Y.

brother(X,Y):-man(X),parent(X,P),parent(Y,P),X\=Y.

sister(X,Y):-woman(X),parent(X,P),parent(Y,P),X\=Y.

grandfather(X,Y):-man(X),parent(Y,P),parent(P,X),X\=Y.
grandmother(X,Y):-woman(X),parent(Y,P),parent(P,X),X\=Y.
