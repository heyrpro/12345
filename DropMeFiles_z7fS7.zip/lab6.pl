/*
start:-consult("C:\\Users\\Marat\\Desktop\\�����\\���������\\����\\bd.txt").

output:-student(S,B1,B2),write(S),write(": "),write(B1),write(", "),write(B2), nl,fail.

%upAvg:-findall(B1, student(S, B1, B2), L), write(L).
upAvg:-findall(S, student(S, B1, B2), St), findall(B1, student(S, B1, B2), SB1),findall(B2, student(S, B1, B2), SB2), sum(SB1,SB2,Sum),upr(St,Sum).

sum([],[],[]).
sum([H1|T1],[H2|T2],[H|R]):-H is H1+H2, sum(T1,T2,R).

max([X],X).
max([A,B|T],M):-A>=B,!,max([A|T],M).
max([_,B|T],M):-max([B|T],M).

del(_,[],[]).
del(X,[X|L1],L2):-!, del(X,L1,L2).
del(X,[Y|L1],[Y|L2]):-del(X,L1,L2).

upr(_,[]):-!.
upr(S,Sum):-max(Sum,X),del(X,Sum,NSum),student(Sr,B1,B2),Sumb is B1+B2,Sumb=X,retract(student(Sr,B1,B2)),assertz(student(Sr,B1,B2)),addDB,upr([S],[NSum]).

addDB:- tell('C:\\Users\\Marat\\Desktop\\�����\\���������\\����\\bd.txt'), listing(student), told.
*/

start:-consult("C:\\Users\\Marat\\Desktop\\�����\\���������\\����\\bd.txt").

output:-student(S,B1,B2),write(S),write(": "),write(B1),write(", "),write(B2),nl,fail.
output.

create_prom:-student(S,B1,B2),Sum is (B1+B2)/2,assertz(studentSr(S, Sum)),fail.
create_prom.


list:-findall(Sum, studentSr(_,Sum), LSr),bubble_sort(LSr, Res),write_students(Res).


bubble_sort(SortedList, SortedList):-
  bsort(SortedList, DoubleSortedList),
  SortedList = DoubleSortedList, !.
bubble_sort(List, SortedList):-
  bsort(List, SortedPart),
  bubble_sort(SortedPart, SortedList).

bsort([], []):-!.
bsort([Head], [Head]):-!.
bsort([First, Second|Tail], ListWithMaxEnd):-
  First =:= Second, !,
  bsort([Second|Tail], ListWithMaxEnd).
bsort([First, Second|Tail], [Second|ListWithMaxEnd]):-
  First > Second, !,
  bsort([First|Tail], ListWithMaxEnd).
bsort([First, Second|Tail], [First|ListWithMaxEnd]):-
  bsort([Second|Tail], ListWithMaxEnd).


write_students([]):-!.
write_students([H|T]):-write_one(H),write_students(T).

write_one(H):-studentSr(S, H),student(S, B1, B2),write(S),write(": "),write(B1),write(", "),write(B2),retract(student(S, B1, B2)),assertz(student(S, B1, B2)),nl,fail.
write_one(H).

% addDB:-tell("C:\\Users\\Marat\\Desktop\\�����\\���������\\����\\bd_out.txt"),listing(student),told.
%


program:-start,write("�������� ��:"),nl,output,create_prom,nl,write("������������� ��:"),nl,list.
